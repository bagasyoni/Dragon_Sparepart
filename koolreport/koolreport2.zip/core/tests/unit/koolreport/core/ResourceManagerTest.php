<?php
namespace koolreport\core;


class ResourceManagerTest extends \Codeception\Test\Unit
{
    /**
     * @var \UnitTester
     */
    protected $tester;
    
    // tests
    public function testSomeFeature()
    {

    }
}