<?php
    require_once "../../../../autoload.php";
    use \koolreport\widgets\koolphp\Table;
?>

<html>
    <head>
        <title>Test Something</title>
    </head>
    <body>
        <h1>Test Something</h1>
        <p class="lead">
        
            What needed to test?
            How to test?
            How to pass the test?
        
        </p>
    </body>
</html>
