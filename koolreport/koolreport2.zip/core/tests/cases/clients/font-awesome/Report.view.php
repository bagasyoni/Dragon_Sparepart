<html>
    <head>
        <title>Show fontawesome</title>
    </head>
    <body>
        <h1>Show fontawesome</h1>
        <i class="fa fa-users"></i>
        <i class="fab fa-facebook"></i>
    </body>
</html>