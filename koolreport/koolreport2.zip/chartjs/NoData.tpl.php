<div style="text-align:center;font-style:italic;<?php echo $this->width?"width:$this->width;":""; ?><?php echo $this->height?"height:$this->height;":""; ?>">
    No data
</div>