# D3 Package

This package contains D3 based re-usable charts built for KoolReport.

## Documentation

The full documentation can be found at [https://www.koolreport.com/docs/d3/overview](https://www.koolreport.com/docs/d3/overview).