# Change Log

## Version 1.5.0

1. Update dataSource missing message
2. Add clientEvents to all chart
3. Fix the type conversion issue of Waterfall chart.

## Version 1.0.0

